# Stage3 internal A vs B (corpus sums)

Counter: same as pipeline (`count_augmented` / placeholders as 1).

| Channel | input_tokens | output_tokens | saved_tokens | saved_pct | intro_tokens | net_saved_tokens |
|---------|-------------|---------------|--------------|-----------|--------------|------------------|
| Stage3_A_exact_aliasing | 171495 | 169892 | 1603 | 0.9347% | 256 | 1347 |
| Stage3_B_lexical_free_text | 169892 | 168645 | 1247 | 0.7340% | 388 | 859 |
