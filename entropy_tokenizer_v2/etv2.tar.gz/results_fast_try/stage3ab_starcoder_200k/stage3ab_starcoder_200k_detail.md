# Telemetry

| metric | value |
|--------|-------|
| stage3_ab_a_candidates | 8423 |
| stage3_ab_a_selected | 47 |
| stage3_ab_a_used_entries | 47 |
| stage3_ab_a_sequence_saved | 2164 |
| stage3_ab_a_intro_tokens | 256 |
| a_candidates_rejected_min_occ | 4050 |
| a_candidates_rejected_raw_too_short | 260 |
| a_candidates_rejected_alias_conflict | 3953 |
| a_candidates_rejected_gain_non_positive | 111 |
| a_candidates_rejected_context_rescore_negative | 2 |
| b_free_text_candidates_total | 5933 |
| b_free_text_candidates_visible_after_stage2 | 685 |
| b_clusters_formed | 579 |
| b_clusters_rejected_too_small | 0 |
| b_clusters_rejected_similarity_or_quality | 0 |
| b_clusters_rejected_intro_cost | 560 |
| b_clusters_selected_final | 19 |
| stage3_ab_b_sequence_saved | 1073 |
| stage3_ab_b_intro_tokens | 388 |
| stage2_removed_comment_count_sum | 1359 |
| stage2_removed_comment_tokens_sum | 13708 |
| stage2_removed_docstring_count_sum | 0 |
| stage2_removed_docstring_tokens_sum | 0 |
| stage2_removed_free_text_estimated_tokens_sum | 0 |
| stage2_retained_for_b_probe_count_sum | 0 |
| stage2_retained_for_b_probe_tokens_sum | 0 |
| stage3_ab_stage2_input_tokens_sum | 171495 |
| stage3_ab_after_a_tokens_sum | 169892 |
| stage3_ab_after_b_tokens_sum | 168645 |
